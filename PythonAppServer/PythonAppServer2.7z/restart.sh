./stop.sh
./start.sh